import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Navbar from './Navbar';
import MobileBottomNav from './MobileBottomNav';
import { ToastProvider } from './ToastContainer';

const Layout = () => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);

    const handleMenuClick = () => {
        setIsSidebarOpen(true);
    };

    return (
        <ToastProvider>
            <div className="flex h-screen bg-gray-50 font-sans">
                <Sidebar isSidebarOpen={isSidebarOpen} setIsSidebarOpen={setIsSidebarOpen} />

                <div className="flex-1 flex flex-col overflow-hidden">
                    <Navbar isSidebarOpen={isSidebarOpen} setIsSidebarOpen={setIsSidebarOpen} />
                    <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-4 sm:p-6 mobile-bottom-nav-spacing">
                        <Outlet />
                    </main>
                </div>

                {/* Mobile Bottom Navigation */}
                <MobileBottomNav onMenuClick={handleMenuClick} />
            </div>
        </ToastProvider>
    );
};

export default Layout;
