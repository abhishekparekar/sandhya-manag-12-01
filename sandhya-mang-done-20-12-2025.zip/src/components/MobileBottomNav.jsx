import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FiHome, FiBriefcase, FiDollarSign, FiCheckSquare, FiMenu } from 'react-icons/fi';

/**
 * MobileBottomNav Component
 * Fixed bottom navigation for mobile devices
 * Only visible on mobile and tablet screens
 */

const MobileBottomNav = ({ onMenuClick }) => {
    const location = useLocation();

    const navItems = [
        { path: '/', label: 'Home', icon: FiHome },
        { path: '/projects', label: 'Projects', icon: FiBriefcase },
        { path: '/sales', label: 'Sales', icon: FiDollarSign },
        { path: '/tasks', label: 'Tasks', icon: FiCheckSquare },
    ];

    const isActive = (path) => {
        return location.pathname === path;
    };

    return (
        <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg md:hidden z-40 safe-area-bottom">
            <div className="grid grid-cols-5 h-16">
                {navItems.map((item) => {
                    const Icon = item.icon;
                    const active = isActive(item.path);

                    return (
                        <Link
                            key={item.path}
                            to={item.path}
                            className={`flex flex-col items-center justify-center gap-1 transition-all ${active
                                    ? 'text-[#F47920]'
                                    : 'text-gray-600 hover:text-gray-800'
                                }`}
                        >
                            <div className={`relative ${active ? 'animate-bounce-subtle' : ''}`}>
                                <Icon className={`w-5 h-5 ${active ? 'scale-110' : ''} transition-transform`} />
                                {active && (
                                    <div className="absolute -top-1 -right-1 w-2 h-2 bg-[#F47920] rounded-full"></div>
                                )}
                            </div>
                            <span className={`text-[10px] font-medium ${active ? 'font-bold' : ''}`}>
                                {item.label}
                            </span>
                        </Link>
                    );
                })}

                {/* Menu button */}
                <button
                    onClick={onMenuClick}
                    className="flex flex-col items-center justify-center gap-1 text-gray-600 hover:text-gray-800 transition-all"
                >
                    <FiMenu className="w-5 h-5" />
                    <span className="text-[10px] font-medium">Menu</span>
                </button>
            </div>

            {/* Active indicator bar */}
            <div
                className="absolute top-0 h-0.5 bg-gradient-to-r from-[#F47920] to-[#E06810] transition-all duration-300"
                style={{
                    width: '20%',
                    left: `${navItems.findIndex(item => isActive(item.path)) * 20}%`,
                }}
            />
        </nav>
    );
};

export default MobileBottomNav;
