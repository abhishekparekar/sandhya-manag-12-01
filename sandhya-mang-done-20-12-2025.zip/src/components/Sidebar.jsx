import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
    FiHome, FiUsers, FiBriefcase, FiDollarSign, FiPhone,
    FiBox, FiAward, FiLogOut, FiSettings,
    FiTrendingUp, FiCheckSquare, FiCreditCard, FiBarChart2,
    FiUserPlus, FiActivity, FiFolder, FiChevronRight, FiShield,
    FiChevronLeft, FiMenu
} from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';
import { db } from '../services/firebase';
import { doc, onSnapshot } from 'firebase/firestore';

const Sidebar = ({ isSidebarOpen, setIsSidebarOpen }) => {
    const { logout, checkAccess, userRole } = useAuth();
    const location = useLocation();
    const navigate = useNavigate();
    const [logo, setLogo] = useState('/logo.jpg');
    const [isCollapsed, setIsCollapsed] = useState(false);

    useEffect(() => {
        const unsubscribe = onSnapshot(doc(db, 'settings', 'company'), (docSnap) => {
            if (docSnap.exists()) {
                const data = docSnap.data();
                if (data.logoBase64) {
                    setLogo(data.logoBase64);
                } else {
                    setLogo('/logo.jpg');
                }
            }
        }, (error) => {
            console.error("Error fetching logo:", error);
            setLogo('/logo.jpg');
        });

        return () => unsubscribe();
    }, []);

    // Auto-collapse on mobile
    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth < 768) {
                setIsCollapsed(false);
            }
        };

        handleResize();
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const handleLogout = async () => {
        try {
            await logout();
            navigate('/login');
        } catch (error) {
            console.error("Failed to log out", error);
        }
    };

    const toggleSidebar = () => {
        setIsCollapsed(!isCollapsed);
    };

    const menuSections = [
        {
            title: 'Main',
            items: [
                { path: '/', label: 'Dashboard', icon: FiHome, module: 'dashboard', color: 'orange' },
            ]
        },
        {
            title: 'Business',
            items: [
                { path: '/projects', label: 'Projects', icon: FiBriefcase, module: 'projects', color: 'blue' },
                { path: '/sales', label: 'Sales', icon: FiDollarSign, module: 'sales', color: 'green' },
                { path: '/finance', label: 'Finance', icon: FiTrendingUp, module: 'finance', color: 'emerald' },
                { path: '/telecalling', label: 'Telecalling', icon: FiPhone, module: 'telecalling', color: 'amber' },
                { path: '/expenses', label: 'Expenses', icon: FiCreditCard, module: 'expenses', color: 'red' },
                { path: '/inventory', label: 'Inventory', icon: FiBox, module: 'inventory', color: 'teal' },
            ]
        },
        {
            title: 'Team',
            items: [
                { path: '/employees', label: 'Employees', icon: FiUsers, module: 'employees', color: 'purple' },
                { path: '/internship', label: 'Internship', icon: FiUserPlus, module: 'internship', color: 'violet' },
                { path: '/tasks', label: 'Tasks', icon: FiCheckSquare, module: 'tasks', color: 'indigo' },
                { path: '/progress', label: 'Progress', icon: FiActivity, module: 'progress', color: 'lime' },
            ]
        },
        {
            title: 'Documents',
            items: [
                { path: '/certificates', label: 'Certificates', icon: FiAward, module: 'certificates', color: 'yellow' },
                { path: '/id-cards', label: 'ID Cards', icon: FiCreditCard, module: 'idCards', color: 'cyan' },
                { path: '/documents', label: 'Documents', icon: FiFolder, module: 'documents', color: 'slate' },
            ]
        },
        {
            title: 'Analytics',
            items: [
                { path: '/reports', label: 'Reports', icon: FiBarChart2, module: 'reports', color: 'pink' },
            ]
        },
        {
            title: 'Admin',
            items: [
                { path: '/users', label: 'User Management', icon: FiShield, module: 'userManagement', color: 'rose' },
            ]
        },
    ];

    const getColorClasses = (color, isActive) => {
        if (isActive) {
            return 'bg-gradient-to-r from-[#F47920] to-[#E06810] text-white shadow-lg scale-105';
        }

        const hoverColors = {
            orange: 'hover:bg-orange-50 hover:text-orange-600',
            blue: 'hover:bg-blue-50 hover:text-blue-600',
            green: 'hover:bg-green-50 hover:text-green-600',
            emerald: 'hover:bg-emerald-50 hover:text-emerald-600',
            amber: 'hover:bg-amber-50 hover:text-amber-600',
            red: 'hover:bg-red-50 hover:text-red-600',
            teal: 'hover:bg-teal-50 hover:text-teal-600',
            purple: 'hover:bg-purple-50 hover:text-purple-600',
            violet: 'hover:bg-violet-50 hover:text-violet-600',
            indigo: 'hover:bg-indigo-50 hover:text-indigo-600',
            lime: 'hover:bg-lime-50 hover:text-lime-600',
            yellow: 'hover:bg-yellow-50 hover:text-yellow-600',
            cyan: 'hover:bg-cyan-50 hover:text-cyan-600',
            slate: 'hover:bg-slate-50 hover:text-slate-600',
            pink: 'hover:bg-pink-50 hover:text-pink-600',
            rose: 'hover:bg-rose-50 hover:text-rose-600',
        };

        return `text-gray-700 ${hoverColors[color] || 'hover:bg-gray-50'}`;
    };

    const isActive = (path) => location.pathname === path;

    return (
        <>
            {/* Mobile Overlay */}
            {isSidebarOpen && (
                <div
                    className="fixed inset-0 bg-black/60 z-20 md:hidden backdrop-blur-sm transition-opacity duration-300"
                    onClick={() => setIsSidebarOpen(false)}
                />
            )}

            <aside
                className={`fixed md:relative bg-white text-gray-800 transition-all duration-300 ease-in-out h-full z-30 border-r border-gray-200 shadow-xl flex flex-col ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
                    } ${isCollapsed ? 'md:w-20' : 'md:w-72'
                    } w-72`}
            >
                {/* Header with Logo and Toggle */}
                <div className={`relative border-b border-gray-200 bg-gradient-to-br from-[#F47920] to-[#E06810] transition-all duration-300 ${isCollapsed ? 'h-20' : 'h-24'
                    }`}>
                    {/* Desktop Toggle Button */}
                    <button
                        onClick={toggleSidebar}
                        className="hidden md:flex absolute -right-3 top-8 w-6 h-6 bg-[#F47920] text-white rounded-full items-center justify-center shadow-lg hover:bg-[#E06810] transition-all hover:scale-110 z-10"
                        aria-label="Toggle Sidebar"
                    >
                        {isCollapsed ? <FiChevronRight className="w-3 h-3" /> : <FiChevronLeft className="w-3 h-3" />}
                    </button>

                    {/* Logo Container */}
                    <div className={`h-full flex items-center justify-center p-4 transition-all duration-300 ${isCollapsed ? 'px-2' : 'px-6'
                        }`}>
                        <div className="bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 p-2 w-full flex items-center justify-center">
                            <img
                                src={logo}
                                alt="Company Logo"
                                className={`object-contain transition-all duration-300 ${isCollapsed ? 'h-10 w-10' : 'h-14 w-auto max-w-full'
                                    }`}
                                onError={(e) => {
                                    e.target.src = '/logo.jpg';
                                }}
                            />
                        </div>
                    </div>

                    {/* Mobile Close Button */}
                    <button
                        onClick={() => setIsSidebarOpen(false)}
                        className="md:hidden absolute top-4 right-4 w-8 h-8 bg-white/20 text-white rounded-lg flex items-center justify-center hover:bg-white/30 transition-all"
                    >
                        <FiChevronLeft className="w-5 h-5" />
                    </button>
                </div>

                {/* User Info Section */}
                {!isCollapsed && (
                    <div className="px-4 py-4 border-b border-gray-100 bg-gradient-to-r from-orange-50 to-amber-50 animate-slide-down">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#F47920] to-[#E06810] flex items-center justify-center text-white font-bold shadow-md">
                                {userRole?.charAt(0).toUpperCase() || 'U'}
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className="text-sm font-bold text-gray-800 truncate">
                                    {userRole?.charAt(0).toUpperCase() + userRole?.slice(1) || 'User'}
                                </p>
                                <p className="text-xs text-gray-600 truncate">Sandhya Management</p>
                            </div>
                        </div>
                    </div>
                )}

                {/* Navigation Menu */}
                <nav className="flex-1 overflow-y-auto py-4 px-3 custom-scrollbar-enhanced bg-gray-50">
                    {menuSections.map((section, sectionIndex) => {
                        const accessibleItems = section.items.filter(item =>
                            !item.module || checkAccess(item.module)
                        );

                        if (accessibleItems.length === 0) return null;

                        return (
                            <div key={sectionIndex} className={sectionIndex > 0 ? 'mt-6' : ''}>
                                {/* Section Title */}
                                {!isCollapsed && (
                                    <h3 className="px-3 mb-2 text-[11px] font-bold text-gray-500 uppercase tracking-wider">
                                        {section.title}
                                    </h3>
                                )}

                                {/* Section Divider for Collapsed */}
                                {isCollapsed && sectionIndex > 0 && (
                                    <div className="w-full h-px bg-gray-300 my-3" />
                                )}

                                {/* Section Items */}
                                <ul className="space-y-1">
                                    {accessibleItems.map((item) => {
                                        const active = isActive(item.path);
                                        const Icon = item.icon;

                                        return (
                                            <li key={item.path}>
                                                <Link
                                                    to={item.path}
                                                    onClick={() => setIsSidebarOpen(false)}
                                                    className={`flex items-center px-3 py-2.5 rounded-xl transition-all duration-200 group relative ${getColorClasses(item.color, active)
                                                        } ${active ? 'font-semibold' : 'font-medium'}`}
                                                >
                                                    {/* Icon */}
                                                    <span className={`flex items-center justify-center transition-all duration-200 ${active ? 'text-white scale-110' : 'text-gray-600 group-hover:scale-110'
                                                        } ${isCollapsed ? 'mx-auto' : ''}`}>
                                                        <Icon className="w-5 h-5" />
                                                    </span>

                                                    {/* Label */}
                                                    {!isCollapsed && (
                                                        <span className="ml-3 text-[15px] whitespace-nowrap transition-all duration-300">
                                                            {item.label}
                                                        </span>
                                                    )}

                                                    {/* Active Indicator */}
                                                    {active && !isCollapsed && (
                                                        <span className="ml-auto">
                                                            <FiChevronRight className="w-4 h-4 animate-pulse" />
                                                        </span>
                                                    )}

                                                    {/* Active Dot for Collapsed */}
                                                    {active && isCollapsed && (
                                                        <span className="absolute -right-1 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                                                    )}

                                                    {/* Tooltip for Collapsed */}
                                                    {isCollapsed && (
                                                        <div className="hidden md:block absolute left-full top-1/2 -translate-y-1/2 ml-4 px-3 py-2 bg-gray-900 text-white text-sm font-medium rounded-lg invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-all whitespace-nowrap z-50 shadow-xl">
                                                            {item.label}
                                                            <div className="absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-gray-900" />
                                                        </div>
                                                    )}
                                                </Link>
                                            </li>
                                        );
                                    })}
                                </ul>
                            </div>
                        );
                    })}
                </nav>

                {/* Footer Actions */}
                <div className="p-3 border-t border-gray-200 bg-white space-y-2">
                    {/* Settings */}
                    <Link
                        to="/settings"
                        onClick={() => setIsSidebarOpen(false)}
                        className={`flex items-center px-3 py-2.5 rounded-xl transition-all duration-200 group relative ${isActive('/settings')
                                ? 'bg-gradient-to-r from-[#F47920] to-[#E06810] text-white shadow-lg font-semibold'
                                : 'text-gray-700 hover:bg-gray-100 font-medium'
                            }`}
                    >
                        <FiSettings className={`w-5 h-5 ${isActive('/settings') ? 'text-white' : 'text-gray-600'} ${isCollapsed ? 'mx-auto' : ''
                            }`} />
                        {!isCollapsed && (
                            <span className="ml-3 text-[15px] whitespace-nowrap">Settings</span>
                        )}
                        {isCollapsed && (
                            <div className="hidden md:block absolute left-full top-1/2 -translate-y-1/2 ml-4 px-3 py-2 bg-gray-900 text-white text-sm font-medium rounded-lg invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-all whitespace-nowrap z-50 shadow-xl">
                                Settings
                                <div className="absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-gray-900" />
                            </div>
                        )}
                    </Link>

                    {/* Logout */}
                    <button
                        onClick={handleLogout}
                        className={`flex items-center w-full px-3 py-2.5 rounded-xl text-red-600 hover:bg-red-50 transition-all duration-200 group relative font-medium ${isCollapsed ? 'justify-center' : ''
                            }`}
                    >
                        <FiLogOut className={`w-5 h-5 ${isCollapsed ? 'mx-auto' : ''}`} />
                        {!isCollapsed && (
                            <span className="ml-3 text-[15px] whitespace-nowrap">Logout</span>
                        )}
                        {isCollapsed && (
                            <div className="hidden md:block absolute left-full top-1/2 -translate-y-1/2 ml-4 px-3 py-2 bg-red-600 text-white text-sm font-medium rounded-lg invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-all whitespace-nowrap z-50 shadow-xl">
                                Logout
                                <div className="absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-red-600" />
                            </div>
                        )}
                    </button>
                </div>
            </aside>
        </>
    );
};

export default Sidebar;
